package com.example.amogh.codeera;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import java.util.*;

import static android.app.PendingIntent.getActivity;

public class MainActivity extends AppCompatActivity {

    int marksCount = 0;
    String correctAns, userAns;
    String ans6;
    Boolean ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onRadioButtonClicked(View view) {
        // Is RadioButton now checked?
        ans = ((RadioButton) view).isChecked();

        //Checks which RadioButton is Selected for Question 1
        correctAns = "Aashadhi Beej";
        userAns = (String) ((RadioButton) view).getText();
        switch (view.getId()) {
            case R.id.op1_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op1_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op1_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op1_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 2
        correctAns = "Nagaland";
        switch (view.getId()) {
            case R.id.op2_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op2_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op2_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op2_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 3
        correctAns = "Dhrupad";
        switch (view.getId()) {
            case R.id.op3_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op3_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op3_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op3_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 4
        correctAns = "Jaipur";
        switch (view.getId()) {
            case R.id.op4_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op4_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op4_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op4_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 5
        correctAns = "President";
        switch (view.getId()) {
            case R.id.op5_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op5_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op5_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op5_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 7
        correctAns = "1969";
        switch (view.getId()) {
            case R.id.op7_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op7_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op7_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op7_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 8
        correctAns = "Vitthal";
        switch (view.getId()) {
            case R.id.op8_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op8_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op8_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op8_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }

        //Checks which RadioButton is Selected for Question 10
        correctAns = "Bharatnatyam";
        switch (view.getId()) {
            case R.id.op10_1:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op10_2:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op10_3:
                if (ans) {
                    getAnswer(userAns);
                }
                break;

            case R.id.op10_4:
                if (ans) {
                    getAnswer(userAns);
                }
                break;
        }
    }

    /**
     *
     * @param userInput gets the user choice, and if it is correct then increases the mark by 1.
     */
    public void getAnswer(String userInput){
        if (userInput.equals(correctAns)) {
            marksCount += 1;
        }
    }

    /*
     * Get the user Answer from EditText
     */
    public void getTextAns(){
        correctAns = "Rasthrakutas";
        EditText etAns_6 =(EditText) findViewById(R.id.ans_6);
        ans6 = etAns_6.getText().toString();

        if(correctAns.equalsIgnoreCase(ans6)){
            marksCount += 1;
        }
    }

    public void onCheckboxClicked(View view) {
        // Is CheckBox checked now?
        CheckBox op1 = findViewById(R.id.op9_1);
        CheckBox op2 = findViewById(R.id.op9_2);
        CheckBox op3 = findViewById(R.id.op9_3);
        CheckBox op4 = findViewById(R.id.op9_4);
        CheckBox op5 = findViewById(R.id.op9_5);

        //Checks which CheckBoxes are Selected.
        if(op1.isChecked() && op3.isChecked() && op4.isChecked() && !op5.isChecked() && !op2.isChecked()){
            marksCount += 1;
        }
    }

    public void submitQuiz(View view) {
        getTextAns();
       /** TextView totalMarks = (TextView) findViewById(R.id.total_marks);
        String marks = "Total Marks : " + marksCount;
        totalMarks.setText(marks);*/

       AlertDialog.Builder marksDialogBuilder = new AlertDialog.Builder(this);
       marksDialogBuilder.setTitle("Result");
       if(marksCount > 6) {
           marksDialogBuilder
                   .setMessage("Congrats! You Scored : " + marksCount)
                   .setCancelable(false)
                   .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                       @SuppressLint("ResourceType")
                       public void onClick(DialogInterface dialog, int id) {

                           // current activity
                           setContentView(R.layout.activity_main);
                       }
                   });
       }
       else if((marksCount < 6)) {
           marksDialogBuilder
                   .setMessage("Try Again. Your Score : " + marksCount)
                   .setCancelable(false)
                   .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                       @SuppressLint("ResourceType")
                       public void onClick(DialogInterface dialog, int id) {

                           // current activity
                           setContentView(R.layout.activity_main);
                       }
                   });
       }

       AlertDialog alert = marksDialogBuilder.create();

       alert.show();
    }
}
